function buttOnClick() {
    let rentCar = document.querySelectorAll(".rental-car");
    rentCar.style.width = '600px';
}